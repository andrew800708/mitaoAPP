# Telegram 商务服务 Mini App v1

这是第一版前端 MVP，可直接部署到 Cloudflare Pages、Vercel、Netlify 等静态托管平台。

## 当前功能
- Telegram WebApp SDK 初始化
- 首页 / 城市筛选 / 服务分类
- 服务人员列表
- 服务详情
- 预约时间选择
- 本地订单演示
- 我的页面
- Telegram 用户昵称读取
- 手机端适配

## 当前还是演示版
订单目前保存在浏览器 localStorage，尚未连接数据库。
下一阶段接入：
1. Cloudflare Worker API
2. D1 数据库
3. 管理员后台
4. 真正的订单状态
5. 商家入驻
6. 图片上传
7. 客服系统
8. Telegram Bot 菜单按钮 / Launch App

## 部署
把整个目录上传到 Cloudflare Pages，构建命令留空，输出目录为当前目录。

部署后得到一个 HTTPS 地址，例如：
https://your-miniapp.pages.dev

然后在 @BotFather 中给你的 Bot 配置 Mini App / Menu Button，URL 填这个 HTTPS 地址。

## 安全
生产环境不要相信前端传来的用户身份或价格。
后台必须在服务器端验证 Telegram initData，并由服务器计算订单价格。


## 会员支付（V1.1）
已加入会员中心、套餐选择、Stars/月的界面及真实支付接口预留。
生产支付必须由后端使用 Bot Token 调用 Telegram Bot API `createInvoiceLink`：
- currency = `XTR`
- subscription_period = `2592000`（30天）
- prices 中使用套餐 Stars 数量
- 收到 `successful_payment` 后才把用户会员状态写入数据库
- 保存 `telegram_payment_charge_id`，用于后续退款处理

Telegram 官方说明：Mini App 内数字商品/数字服务使用 Telegram Stars；Bot 订阅目前支持每30天自动扣款。不要把 Bot Token 放进前端。
