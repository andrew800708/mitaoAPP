const tg=window.Telegram?.WebApp;
if(tg){tg.ready();tg.expand();document.body.style.background=tg.backgroundColor||'#f5f7fa';}
const providers=[
 {id:1,name:'林悦',city:'北京',area:'朝阳区',distance:'3公里',rating:'4.9',count:'236+',tags:['按摩理疗','精品SPA','肩颈放松'],desc:'专业服务团队，注重体验与服务品质。',price:298},
 {id:2,name:'陈晓',city:'北京',area:'西城区',distance:'5公里',rating:'4.8',count:'189+',tags:['美容护理','面部护理','皮肤管理'],desc:'专注品质护理，为客户提供专业服务。',price:268},
 {id:3,name:'王婷',city:'北京',area:'海淀区',distance:'6公里',rating:'4.7',count:'152+',tags:['家政服务','保洁清洁','收纳整理'],desc:'细心负责，服务规范，值得信赖。',price:198},
 {id:4,name:'李明',city:'北京',area:'朝阳区',distance:'4公里',rating:'4.9',count:'211+',tags:['商务顾问','商务咨询','资源对接'],desc:'拥有丰富行业经验，提供专业商务咨询。',price:498},
 {id:5,name:'刘芳',city:'上海',area:'静安区',distance:'7公里',rating:'4.8',count:'176+',tags:['美容护理','SPA','形象管理'],desc:'专业团队服务，预约灵活。',price:328}
];
const cats=[['✦','按摩理疗'],['♧','美容护理'],['⌂','家政服务'],['▣','商务顾问'],['▦','活动预约']];
let currentCity='北京',currentProvider=providers[0];
function img(seed){return `https://i.pravatar.cc/140?img=${seed+20}`}
function go(page){
 document.querySelectorAll('.page').forEach(p=>p.classList.remove('active'));
 document.getElementById(page).classList.add('active');
 document.querySelectorAll('.bottom-nav button').forEach(b=>b.classList.toggle('active',b.dataset.page===page));
 if(page==='category')renderProviders(); if(page==='orders')renderOrders();
}
function renderHome(){
 document.getElementById('cityRow').innerHTML=['北京','上海','广州','深圳'].map(c=>`<button class="${c===currentCity?'selected':''}" onclick="selectCity('${c}')">${c}</button>`).join('');
 document.getElementById('categories').innerHTML=cats.map(c=>`<div class="cat" onclick="go('category')"><span class="emoji">${c[0]}</span>${c[1]}</div>`).join('');
 document.getElementById('recommendations').innerHTML=providers.slice(0,3).map(p=>providerCard(p)).join('');
}
function selectCity(c){currentCity=c;renderHome();renderProviders();}
function providerCard(p){return `<div class="card"><img class="avatar-img" src="${img(p.id)}"><div class="card-main"><div class="name-line"><span class="name">${p.name} <span class="verified">●</span></span><span class="rating">★ ${p.rating}</span></div><div class="meta">📍 ${p.city} · ${p.area} · 近${p.distance}</div><div class="tags">${p.tags.map(t=>`<span>${t}</span>`).join('')}</div><div class="desc">${p.desc}</div><button class="book" onclick="openDetail(${p.id})">立即预约</button></div></div>`}
function renderProviders(){
 document.getElementById('categoryFilters').innerHTML=['全部','按摩理疗','美容护理','家政服务','商务顾问'].map((x,i)=>`<button class="${i===0?'selected':''}">${x}</button>`).join('');
 const list=providers.filter(p=>p.city===currentCity||currentCity==='北京');
 document.getElementById('providerList').innerHTML=list.length?list.map(providerCard).join(''):'<div class="empty">当前城市正在扩充服务商</div>';
}
function openDetail(id){currentProvider=providers.find(p=>p.id===id)||providers[0];const p=currentProvider;
 document.getElementById('detailContent').innerHTML=`<div class="detail-cover">✦</div><div class="detail-head"><h2>${p.name} <span class="verified">●</span></h2><div class="meta">★ ${p.rating} · 已服务 ${p.count} · 📍${p.city} ${p.area}</div><div class="tags">${p.tags.map(t=>`<span>${t}</span>`).join('')}</div><p class="desc">${p.desc}</p><h3>服务项目</h3>
 ${[['标准服务（60分钟）',298],['精品服务（90分钟）',398],['专项护理（45分钟）',268]].map(x=>`<div class="price-row"><span>${x[0]}</span><span class="price">¥${x[1]}</span></div>`).join('')}
 <h3>可预约时间</h3><div class="time-grid">${['10:00','11:30','14:00','16:30','18:00','19:30'].map((t,i)=>`<button class="${i===1?'selected':''}" onclick="this.classList.toggle('selected')">${t}</button>`).join('')}</div>
 <p class="meta">📍 服务地点将在预约确认后显示</p><button class="primary" onclick="createOrder()">预约服务</button></div>`;
 go('detail');
}
function createOrder(){let orders=JSON.parse(localStorage.getItem('orders')||'[]');orders.unshift({name:currentProvider.name,service:'标准服务（60分钟）',price:298,status:'待确认',time:new Date().toLocaleString('zh-CN')});localStorage.setItem('orders',JSON.stringify(orders));showNotice('预约已提交，请等待确认');setTimeout(()=>go('orders'),700);}
function renderOrders(){let orders=JSON.parse(localStorage.getItem('orders')||'[]');document.getElementById('orderCount').textContent=orders.length;document.getElementById('ordersList').innerHTML=orders.length?orders.map(o=>`<div class="order"><div class="order-top"><b>${o.service}</b><span class="status">${o.status}</span></div><div class="meta">服务商：${o.name}</div><div class="meta">${o.time}</div><div style="margin-top:8px"><b class="price">¥${o.price}</b></div></div>`).join(''):'<div class="empty">暂无订单<br><small>预约服务后将在这里显示</small></div>'}
function showNotice(t){const e=document.getElementById('toast');e.textContent=t;e.style.display='block';clearTimeout(window._toast);window._toast=setTimeout(()=>e.style.display='none',2200)}
function initUser(){const u=tg?.initDataUnsafe?.user;if(u){document.getElementById('userName').textContent=[u.first_name,u.last_name].filter(Boolean).join(' ')||'Telegram 用户';document.getElementById('avatar').textContent=(u.first_name||'U')[0].toUpperCase()}}
renderHome();renderProviders();renderOrders();initUser();
const membershipPlans=[
 {id:'basic',name:'初级会员',stars:88,desc:'基础会员权益',benefits:['会员专属标识','优先客服响应']},
 {id:'pro',name:'中级会员',stars:188,desc:'适合长期使用',benefits:['会员专属标识','优先预约','专属优惠','更多会员权益'],recommended:true},
 {id:'elite',name:'高级会员',stars:588,desc:'高阶会员服务',benefits:['全部中级会员权益','专属客服','优先处理','专属活动']}
];
function renderMembership(){
 document.getElementById('membershipPlans').innerHTML=membershipPlans.map((p,i)=>`<div class="plan ${p.recommended?'recommended':''}" onclick="selectPlan('${p.id}')">
 ${p.recommended?'<span class="recommend">推荐</span>':''}
 <h3>${p.name}</h3><div class="meta">${p.desc}</div>
 <div class="plan-price">${p.stars} <small>Stars / 月</small></div>
 <ul>${p.benefits.map(x=>`<li>${x}</li>`).join('')}</ul>
 </div>`).join('');
}
let selectedPlan='pro';
function selectPlan(id){selectedPlan=id;document.querySelectorAll('.plan').forEach((e,i)=>e.style.boxShadow='');const idx=membershipPlans.findIndex(p=>p.id===id);const el=document.querySelectorAll('.plan')[idx];if(el)el.style.boxShadow='0 0 0 2px #d6a33b inset';}
async function payMembership(){
 if(!document.getElementById('termsCheck').checked){showNotice('请先同意会员服务条款');return}
 const p=membershipPlans.find(x=>x.id===selectedPlan);
 /*
 生产环境：后端 /api/create-membership-invoice 必须使用 Bot Token 调用
 Telegram Bot API createInvoiceLink，currency=XTR，subscription_period=2592000，
 并返回 invoice_link。不要在前端放 Bot Token。
 */
 try{
   const res=await fetch('/api/create-membership-invoice',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({plan:p.id,stars:p.stars,telegram_user_id:tg?.initDataUnsafe?.user?.id||null,initData:tg?.initData||''})});
   if(!res.ok) throw new Error('invoice endpoint unavailable');
   const data=await res.json();
   if(data.invoice_link && tg?.openInvoice){
      tg.openInvoice(data.invoice_link,(status)=>{ if(status==='paid'){showNotice('支付成功，会员将在确认后生效')} else if(status==='cancelled'){showNotice('已取消支付')} else if(status==='failed'){showNotice('支付失败，请重试')} });
   }else throw new Error('no invoice');
 }catch(e){
   showNotice('支付接口尚未部署：下一步接入 Telegram Stars');
 }
}
renderMembership();selectPlan('pro');
