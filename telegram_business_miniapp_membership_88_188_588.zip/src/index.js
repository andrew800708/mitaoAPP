const PLANS = {
  basic: { name: '初级会员', stars: 88, days: 30, lifetime: false },
  pro: { name: '中级会员', stars: 188, days: 30, lifetime: false },
  elite: { name: '高级会员', stars: 588, days: null, lifetime: true },
};

const json = (data, status = 200) => new Response(JSON.stringify(data), {
  status,
  headers: { 'content-type': 'application/json; charset=utf-8' },
});

function nowIso() { return new Date().toISOString(); }

async function hmacSha256(keyBytes, data) {
  const key = await crypto.subtle.importKey(
    'raw', keyBytes,
    { name: 'HMAC', hash: 'SHA-256' },
    false, ['sign']
  );
  return new Uint8Array(await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(data)));
}

function hex(bytes) {
  return [...bytes].map(b => b.toString(16).padStart(2, '0')).join('');
}

function safeEqual(a, b) {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

async function validateInitData(initData, botToken) {
  if (!initData || !botToken) throw new Error('Missing Telegram initData');
  const params = new URLSearchParams(initData);
  const receivedHash = params.get('hash');
  const authDate = Number(params.get('auth_date') || 0);
  if (!receivedHash || !authDate) throw new Error('Invalid Telegram initData');
  // Reject very old WebApp payloads. Adjust if your use case needs a longer window.
  if (Math.floor(Date.now() / 1000) - authDate > 86400) throw new Error('Telegram session expired');

  const pairs = [];
  for (const [key, value] of params.entries()) {
    if (key !== 'hash') pairs.push(`${key}=${value}`);
  }
  pairs.sort();
  const dataCheckString = pairs.join('\n');
  const secret = await hmacSha256(new TextEncoder().encode('WebAppData'), botToken);
  const calculated = hex(await hmacSha256(secret, dataCheckString));
  if (!safeEqual(calculated, receivedHash)) throw new Error('Invalid Telegram initData signature');

  let user = null;
  try { user = JSON.parse(params.get('user') || 'null'); } catch (_) {}
  if (!user?.id) throw new Error('Telegram user not found');
  return user;
}

async function telegramApi(env, method, body) {
  const res = await fetch(`https://api.telegram.org/bot${env.BOT_TOKEN}/${method}`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  });
  const data = await res.json();
  if (!data.ok) throw new Error(data.description || `Telegram API ${method} failed`);
  return data.result;
}

async function upsertUser(env, user) {
  const now = nowIso();
  await env.DB.prepare(`
    INSERT INTO users (telegram_user_id, username, first_name, last_name, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?)
    ON CONFLICT(telegram_user_id) DO UPDATE SET
      username=excluded.username,
      first_name=excluded.first_name,
      last_name=excluded.last_name,
      updated_at=excluded.updated_at
  `).bind(
    user.id,
    user.username || null,
    user.first_name || null,
    user.last_name || null,
    now,
    now
  ).run();
}

async function createInvoice(request, env) {
  let body;
  try { body = await request.json(); } catch (_) { return json({ error: 'Invalid JSON' }, 400); }
  let user;
  try { user = await validateInitData(body.initData, env.BOT_TOKEN); }
  catch (e) { return json({ error: e.message }, 401); }

  const plan = PLANS[body.plan];
  if (!plan) return json({ error: 'Invalid membership plan' }, 400);

  await upsertUser(env, user);
  const orderId = crypto.randomUUID();
  const payload = `membership:${orderId}`;
  const now = nowIso();

  await env.DB.prepare(`
    INSERT INTO membership_orders
      (id, telegram_user_id, plan_id, stars, status, invoice_payload, created_at)
    VALUES (?, ?, ?, ?, 'pending', ?, ?)
  `).bind(orderId, user.id, plan.id, plan.stars, payload, now).run();

  try {
    const origin = new URL(request.url).origin;
    const invoiceLink = await telegramApi(env, 'createInvoiceLink', {
      title: plan.name,
      description: `${plan.name} · 30天自动续费会员`,
      payload,
      provider_token: '',
      currency: 'XTR',
      prices: [{ label: plan.name, amount: plan.stars }],
      subscription_period: 2592000,
      terms_url: `${origin}/terms.html`,
    });
    return json({ invoice_link: invoiceLink, order_id: orderId });
  } catch (e) {
    await env.DB.prepare(`UPDATE membership_orders SET status='invoice_failed' WHERE id=?`).bind(orderId).run();
    return json({ error: e.message }, 502);
  }
}

async function getMe(request, env) {
  const url = new URL(request.url);
  const initData = url.searchParams.get('initData') || request.headers.get('x-telegram-init-data') || '';
  let user;
  try { user = await validateInitData(initData, env.BOT_TOKEN); }
  catch (e) { return json({ error: e.message }, 401); }

  const row = await env.DB.prepare(`
    SELECT * FROM membership_orders
    WHERE telegram_user_id=? AND status='paid'
    ORDER BY paid_at DESC LIMIT 1
  `).bind(user.id).first();

  return json({
    telegram_user_id: user.id,
    membership: row ? {
      plan: row.plan_id,
      stars: row.stars,
      expiration_date: row.subscription_expiration_date,
      paid_at: row.paid_at,
    } : null,
  });
}

async function handleWebhook(request, env) {
  const secret = request.headers.get('X-Telegram-Bot-Api-Secret-Token');
  if (!env.WEBHOOK_SECRET || secret !== env.WEBHOOK_SECRET) return new Response('Forbidden', { status: 403 });

  let update;
  try { update = await request.json(); } catch (_) { return new Response('Bad Request', { status: 400 }); }

  if (update.pre_checkout_query) {
    const q = update.pre_checkout_query;
    let ok = false;
    let errorMessage = '订单已失效，请重新发起支付。';
    try {
      const order = await env.DB.prepare(`SELECT * FROM membership_orders WHERE invoice_payload=?`).bind(q.invoice_payload).first();
      const plan = order && PLANS[order.plan_id];
      if (order && plan && order.status === 'pending' && q.currency === 'XTR' && q.total_amount === plan.stars) {
        ok = true;
        errorMessage = '';
      }
    } catch (_) {}
    await telegramApi(env, 'answerPreCheckoutQuery', {
      pre_checkout_query_id: q.id,
      ok,
      ...(ok ? {} : { error_message: errorMessage }),
    });
  }

  const payment = update.message?.successful_payment;
  if (payment) {
    const payload = payment.invoice_payload;
    const order = await env.DB.prepare(`SELECT * FROM membership_orders WHERE invoice_payload=?`).bind(payload).first();
    if (order) {
      const expires = payment.subscription_expiration_date || Math.floor(Date.now() / 1000) + 2592000;
      await env.DB.prepare(`
        UPDATE membership_orders SET
          status='paid',
          telegram_payment_charge_id=?,
          subscription_expiration_date=?,
          paid_at=?
        WHERE id=?
      `).bind(
        payment.telegram_payment_charge_id || null,
        expires,
        nowIso(),
        order.id
      ).run();
    }
  }

  return new Response('OK');
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (request.method === 'POST' && url.pathname === '/api/create-membership-invoice') return createInvoice(request, env);
    if (request.method === 'GET' && url.pathname === '/api/me') return getMe(request, env);
    if (request.method === 'POST' && url.pathname === '/telegram/webhook') return handleWebhook(request, env);

    // Static Mini App assets.
    return env.ASSETS.fetch(request);
  },
};
