CREATE TABLE IF NOT EXISTS users (
  telegram_user_id INTEGER PRIMARY KEY,
  username TEXT,
  first_name TEXT,
  last_name TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS membership_orders (
  id TEXT PRIMARY KEY,
  telegram_user_id INTEGER NOT NULL,
  plan_id TEXT NOT NULL,
  stars INTEGER NOT NULL,
  status TEXT NOT NULL,
  invoice_payload TEXT NOT NULL UNIQUE,
  telegram_payment_charge_id TEXT,
  subscription_expiration_date INTEGER,
  created_at TEXT NOT NULL,
  paid_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_membership_user_status
ON membership_orders (telegram_user_id, status);

CREATE INDEX IF NOT EXISTS idx_membership_payload
ON membership_orders (invoice_payload);
