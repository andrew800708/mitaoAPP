# Telegram Business Mini App + Stars 会员后端部署

这是在前端 Mini App 基础上增加的 Cloudflare Workers + D1 + Telegram Stars 后端。

## 你需要准备
- Cloudflare 账号
- Telegram Bot：@mitao_101bot
- 该 Bot 的 Bot Token（只放到 Cloudflare Secret，不要发给别人）
- 本项目目录

## 1. 安装 Wrangler
```bash
npm install -g wrangler
wrangler login
```

## 2. 创建 D1 数据库
在项目目录执行：
```bash
wrangler d1 create telegram-business-db
```
把返回的 `database_id` 填入 `wrangler.toml`。

## 3. 初始化数据库
```bash
wrangler d1 execute telegram-business-db --remote --file=./schema.sql
```

## 4. 设置 Bot Token
```bash
wrangler secret put BOT_TOKEN
```
粘贴 BotFather 给你的真实 Bot Token。

再设置 Webhook 密钥：
```bash
wrangler secret put WEBHOOK_SECRET
```
可以输入一串自己生成的随机字符串，例如 32~64 位。

## 5. 部署
```bash
wrangler deploy
```
部署后会得到一个 `workers.dev` 地址。

## 6. 设置 Telegram Webhook
把下面的命令中的 BOT_TOKEN 和 Worker 地址换成自己的：
```bash
curl -X POST "https://api.telegram.org/bot<BOT_TOKEN>/setWebhook" \
  -d "url=https://<YOUR_WORKER>.workers.dev/telegram/webhook" \
  -d "secret_token=<YOUR_WEBHOOK_SECRET>"
```

检查：
```bash
curl "https://api.telegram.org/bot<BOT_TOKEN>/getWebhookInfo"
```

## 7. 设置 Mini App
如果 Worker 直接托管本项目静态文件，那么 Mini App URL 就使用 Worker 地址：
`https://<YOUR_WORKER>.workers.dev/`

然后在 BotFather 中把该 URL 设置为 Web App / Mini App 的入口。

## 8. 支付流程
1. 用户进入 Mini App。
2. 选择普通 / 高级 / 高级会员。
3. 前端发送经过 Telegram 签名的 initData 到 `/api/create-membership-invoice`。
4. Worker 验证 initData，并且只相信服务器端价格。
5. Worker 调 Telegram `createInvoiceLink`，货币为 XTR，订阅周期 2592000 秒。
6. Telegram 发送 pre_checkout_query，Webhook 在 10 秒内确认。
7. 收到 successful_payment 后，D1 将订单标记为 paid，并保存 charge id 和订阅到期时间。

## 重要安全规则
- 不要把 Bot Token 写进 `app.js`。
- 不要信任前端传来的 stars 数值，价格以 Worker 的 PLANS 为准。
- 不要仅因为 pre_checkout_query 就开通会员；必须等 successful_payment。
- 不要把 Bot Token 发到聊天、截图或 GitHub。

## 当前会员价格
- 初级会员：88 Stars / 30天
- 中级会员：288 Stars / 30天
- 高级会员：588 Stars / 30天

价格都在 `src/index.js` 的 PLANS 中控制。
